import { useEffect, useState } from "react";
import FlightCard from "../components/FlightSearch/components/FlightCard";
import dummyFlights from "../utils/dummyData";

const FlightResult = () => {
  const [flights, setFlights] = useState([]);

  useEffect(() => {
    // Simulasi fetch API
    setTimeout(() => {
      setFlights(dummyFlights);
    }, 500);
  }, []);

  return (
    <div>
      <h1>Hasil Pencarian</h1>
      {flights.map((flight) => (
        <FlightCard key={flight.id} flight={flight} />
      ))}
    </div>
  );
};

export default FlightResult;
