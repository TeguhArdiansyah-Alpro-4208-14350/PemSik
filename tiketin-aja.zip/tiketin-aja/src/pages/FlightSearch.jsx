import { Toaster } from "react-hot-toast";
import FormFlightSearch from "../components/FlightSearch/components/FormFlightSearch";

const FlightSearch = () => {
  return (
    <div>
      <h1>Teguh Tiket Murah Meriah</h1>
      <FormFlightSearch />
      <Toaster />

      <footer>
      <strong>&copy; TEGUH ARDIANSYAH-A11.2022.14350</strong>
      </footer>
    </div>
  );
};

export default FlightSearch;
