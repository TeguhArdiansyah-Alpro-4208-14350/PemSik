import Swal from "sweetalert2";

const FlightCard = ({ flight }) => {
  const handleOrder = () => {
    Swal.fire("Sukses!", "Tiket berhasil dipesan!", "success");
  };

  return (
    <div className="card">
      <h3>{flight.airline}</h3>
      <p>
        {flight.departure} - {flight.arrival}
      </p>
      <p>Rp {flight.price.toLocaleString()}</p>
      <button onClick={handleOrder}>Pesan</button>
    </div>
  );
};

export default FlightCard;
