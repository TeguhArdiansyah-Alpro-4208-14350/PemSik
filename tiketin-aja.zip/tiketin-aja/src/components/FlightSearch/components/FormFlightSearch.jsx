import CityInput from "./CityInput";
import DateInput from "./DateInput";
import PassengerSelector from "./PassengerSelector";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

const FormFlightSearch = () => {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [date, setDate] = useState("");
  const [passenger, setPassenger] = useState(1);

  const navigate = useNavigate();

  const handleSearch = () => {
    if (from === "" || to === "") {
      toast.error("Isi Dulu Tujuan & Asalnya Bg!");
      return;
    }

    localStorage.setItem(
      "searchData",
      JSON.stringify({ from, to, date, passenger })
    );
    navigate("/hasil");
  };

  return (
    <div>
      <CityInput label="Asal" value={from} onChange={setFrom} placeholder="Dari mana?" />
      <CityInput label="Tujuan" value={to} onChange={setTo} placeholder="Ke mana?" />
      <DateInput value={date} onChange={setDate} />
      <PassengerSelector value={passenger} onChange={setPassenger} />
      <button onClick={handleSearch}>Cari Penerbangan</button>
    </div>
  );
};

export default FormFlightSearch;
