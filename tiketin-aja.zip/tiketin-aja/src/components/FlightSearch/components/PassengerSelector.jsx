const PassengerSelector = ({ value, onChange }) => {
    return (
      <div>
        <label>Jumlah Penumpang</label>
        <input
          type="number"
          value={value}
          min="1"
          max="9"
          onChange={(e) => onChange(e.target.value)}
          className="input"
        />
      </div>
    );
  };
  
  export default PassengerSelector;
  