const CityInput = ({ label, value, onChange, placeholder }) => {
    return (
      <div>
        <label>{label}</label>
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="input"
        />
      </div>
    );
  };
  
  export default CityInput;
  