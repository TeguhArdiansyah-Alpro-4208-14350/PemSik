const DateInput = ({ value, onChange }) => {
    return (
      <div>
        <label>Tanggal Keberangkatan</label>
        <input
          type="date"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="input"
        />
      </div>
    );
  };
  
  export default DateInput;
  