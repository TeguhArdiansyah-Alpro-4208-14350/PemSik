import { Routes, Route } from 'react-router-dom'
import FlightSearch from './pages/FlightSearch'
import FlightResult from './pages/FlightResult'

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<FlightSearch />} />
      <Route path="/hasil" element={<FlightResult />} />
    </Routes>
  )
}

export default AppRoutes
