const dummyFlights = [
    {
      id: 1,
      airline: "Garuda Didadaku",
      departure: "08:00",
      arrival: "10:00",
      price: 750000,
    },
    {
      id: 2,
      airline: "Hawimau",
      departure: "09:30",
      arrival: "11:45",
      price: 550000,
    },
    {
      id: 3,
      airline: "sing Penting Nyampe",
      departure: "12:00",
      arrival: "14:00",
      price: 600000,
    },
  ];
  
  export default dummyFlights;
  